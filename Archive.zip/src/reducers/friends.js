import {
    GET_CONTACTS,
} from '../actions/auth';

const initialState = {
    contacts: []
}

export default (state = initialState, action) => {
    console.log(action);

    switch (action.type) {
        case GET_CONTACTS:
            return {
                ...state,
                contacts: action.payload,
                error: null,
            };
        default:
            return state;
    }
}
