export const GET_CONTACTS = 'friends/GET_CONTACTS';
import simpleContacts from 'react-native-simple-contacts';

export const updateValue = (type, payload) => (dispatch) => {
    dispatch({
        type,
        payload
    });
};

export const getContacts = () => (dispatch, getState) => {
    simpleContacts.getContacts().then((contacts) => {
        console.log(typeof contacts);
        console.log(contacts.length)
        console.log(contacts);
        /*dispatch({
            type: GET_CONTACTS,
            payload
        })*/
    });
}
